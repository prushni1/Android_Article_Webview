package com.connect2android.androidhive_webview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {


    private WebView webView;


    String url = "http://www.androidhive.info/";


    String customHtml = "<html><body><h1>Hello, WebView</h1>" +
            "<h1>Heading 1</h1><h2>Heading 2</h2><h3>Heading 3</h3>" +
            "<p>This is a sample paragraph.</p>" +
            "</body></html>";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = (WebView) findViewById(R.id.webView1);


        /*
        //THIS OPENS DEFAULT BROWSER

        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("http://www.google.com");
        */


        /*
        //Use this code to Load html :
       // webView.loadData(customHtml, "text/html", "UTF-8");

        */

        webView.setWebViewClient(new MyWebViewClient());

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(true);




       // webView.loadUrl(url);




        //Overriding css
        webView.loadUrl("file:///android_asset/sample.html");

    }

    private class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // Check if the key event was the Back button and if there's history
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        // If it wasn't the Back key or there's no web page history, bubble up to the default
        // system behavior (probably exit the activity)
        return super.onKeyDown(keyCode, event);
    }




}

